import java.util.Scanner;

public class EstacionDelAno {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Pedir al usuario un número de mes
        System.out.print("Ingrese el número del mes (1-12): ");
        int mes = scanner.nextInt();

        // Determinar la estación usando switch-case
        String estacion;
        switch (mes) {
            case 12, 1, 2:
                estacion = "Invierno";
                break;
            case 3, 4, 5:
                estacion = "Primavera";
                break;
            case 6, 7, 8:
                estacion = "Verano";
                break;
            case 9, 10, 11:
                estacion = "Otoño";
                break;
            default:
                estacion = "Mes inválido. Debe estar entre 1 y 12.";
        }

        // Mostrar el resultado
        System.out.println("La estación es: " + estacion);

        scanner.close();
    }
}
